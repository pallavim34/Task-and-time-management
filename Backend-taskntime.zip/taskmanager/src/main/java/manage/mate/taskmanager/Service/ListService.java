package manage.mate.taskmanager.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.NonNull;
import manage.mate.taskmanager.Model.ListModel;
import manage.mate.taskmanager.Repository.ListRepo;

@Service
public class ListService {
    @Autowired
    public ListRepo listRepo;

    public ListModel createnewlist(@NonNull ListModel list)
    {
        return listRepo.save(list);
    }
    public List<ListModel> getAllusers()
    {
        return listRepo.findAll();
    }
    public List<ListModel> getAllListModels() {
        return listRepo.findAll();
    }
    public Optional<ListModel> getListModelById(long id) {
        return listRepo.findById(id);
    }

    public ListModel updateListModel(long id, ListModel updatedListModel) {
        return listRepo.findById(id)
            .map(listModel -> {
                listModel.setKey_id(updatedListModel.getKey_id());
                listModel.setList_name(updatedListModel.getList_name());
                listModel.setWorkspace_id(updatedListModel.getWorkspace_id());
                return listRepo.save(listModel);
            })
            .orElseThrow(() -> new RuntimeException("ListModel not found with id " + id));
    }

    public void deleteListModel(long id) {
        listRepo.deleteById(id);
    }
}
