package manage.mate.taskmanager.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import manage.mate.taskmanager.Model.ListModel;

public interface ListRepo extends JpaRepository<ListModel, Long> { 
}
