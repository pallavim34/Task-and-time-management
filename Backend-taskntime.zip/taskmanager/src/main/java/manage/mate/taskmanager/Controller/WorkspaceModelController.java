package manage.mate.taskmanager.Controller;

import manage.mate.taskmanager.Model.WorkspaceModel;
import manage.mate.taskmanager.Service.WorkspaceModelService;
//import manage.mate.taskmanager.Service.WorkspaceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/workspaces")
public class WorkspaceModelController {

    @Autowired
    private WorkspaceModelService workspaceModelService;

    @GetMapping
    public List<WorkspaceModel> getAllWorkspaces() {
        return workspaceModelService.getAllWorkspaces();
    }

    @GetMapping("/{id}")
    public ResponseEntity<WorkspaceModel> getWorkspaceById(@PathVariable long id) {
        Optional<WorkspaceModel> workspaceModel = workspaceModelService.getWorkspaceById(id);
        return workspaceModel.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public WorkspaceModel createWorkspace(@RequestBody WorkspaceModel workspaceModel) {
        return workspaceModelService.createWorkspace(workspaceModel);
    }

    @PutMapping("/{id}")
    public ResponseEntity<WorkspaceModel> updateWorkspace(@PathVariable long id, @RequestBody WorkspaceModel workspaceDetails) {
        Optional<WorkspaceModel> updatedWorkspace = workspaceModelService.updateWorkspace(id, workspaceDetails);
        return updatedWorkspace.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWorkspace(@PathVariable long id) {
        if (workspaceModelService.deleteWorkspace(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
