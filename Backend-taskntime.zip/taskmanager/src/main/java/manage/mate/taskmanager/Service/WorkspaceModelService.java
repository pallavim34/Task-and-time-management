package manage.mate.taskmanager.Service;

import manage.mate.taskmanager.Model.WorkspaceModel;

import manage.mate.taskmanager.Repository.WorkspaceRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WorkspaceModelService {

    @Autowired
    private WorkspaceRepo workspaceModelRepository;

    public List<WorkspaceModel> getAllWorkspaces() {
        return workspaceModelRepository.findAll();
    }

    public Optional<WorkspaceModel> getWorkspaceById(long id) {
        return workspaceModelRepository.findById(id);
    }

    public WorkspaceModel createWorkspace(WorkspaceModel workspaceModel) {
        return workspaceModelRepository.save(workspaceModel);
    }

    public Optional<WorkspaceModel> updateWorkspace(long id, WorkspaceModel workspaceDetails) {
        return workspaceModelRepository.findById(id).map(workspace -> {
            workspace.setWorkspace_key(workspaceDetails.getWorkspace_key());
            workspace.setWorkspace_name(workspaceDetails.getWorkspace_name());
            return workspaceModelRepository.save(workspace);
        });
    }

    public boolean deleteWorkspace(long id) {
        return workspaceModelRepository.findById(id).map(workspace -> {
            workspaceModelRepository.delete(workspace);
            return true;
        }).orElse(false);
    }
}
