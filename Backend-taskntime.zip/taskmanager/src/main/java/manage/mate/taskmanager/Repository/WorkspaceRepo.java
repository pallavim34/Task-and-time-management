package manage.mate.taskmanager.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import manage.mate.taskmanager.Model.WorkspaceModel;

public interface WorkspaceRepo extends JpaRepository<WorkspaceModel, Long> { 
}