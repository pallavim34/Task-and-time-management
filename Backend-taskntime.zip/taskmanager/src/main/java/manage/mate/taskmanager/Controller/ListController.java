package manage.mate.taskmanager.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.NonNull;
import manage.mate.taskmanager.Model.ListModel;
import manage.mate.taskmanager.Service.ListService;


@RestController
@RequestMapping("/list")
public class ListController {
    @Autowired
    private  ListService listService;
    
    @PostMapping("/createList")
    public ResponseEntity<ListModel> createList(@NonNull @RequestBody ListModel list) {
        ListModel createdList = listService.createnewlist(list);
        return new ResponseEntity<>(createdList, HttpStatus.CREATED);
    }

    @GetMapping("/getList")
    public List<ListModel> getAllListModels() {
        return listService.getAllListModels();
    }

    @GetMapping("/getAllList/{id}")
    public ResponseEntity<ListModel> getListModelById(@PathVariable long id) {
        return listService.getListModelById(id)
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/updateList/{id}")
    public ResponseEntity<ListModel> updateListModel(@PathVariable long id, @RequestBody ListModel updatedListModel) {
        try {
            ListModel updated = listService.updateListModel(id, updatedListModel);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/deleteList/{id}")
    public ResponseEntity<Void> deleteListModel(@PathVariable long id) {
        listService.deleteListModel(id);
        return ResponseEntity.noContent().build();
    }
}
